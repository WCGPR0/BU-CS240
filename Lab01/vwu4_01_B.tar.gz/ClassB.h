#include <iostream>

/** QUESTION 1 */
#ifndef CLASSB_H
#define CLASSB_H

class ClassB {
	
	public:
	void q1(int myArray[], int sizeOfArray, int N, int M);
	void q2(int A, int B);
	int q3(int A, int B);
	void q4(bool A, bool B);
	void q5();
	const char* toString(bool A);
};

#endif
